package br.usp.ime.ex01;

import java.math.BigDecimal;

public class FatorialController {
    public BigDecimal calculateFatorial(String input) throws Exception {
        int number = Integer.parseInt(input);
        if (number < 0) {
            throw new Exception("Número deve ser positivo");
        }

        BigDecimal result = BigDecimal.ONE;
        for (int i = 1; i <= number; i++) {
            result = result.multiply(new BigDecimal(i));
        }
        return result;
    }
}
