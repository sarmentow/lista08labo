package br.usp.ime.ex01;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;

public class FatorialView extends JFrame {
    private static final long serialVersionUID = 1L;
	private JTextField inputField;
    private JButton calculateButton;
    private JLabel resultLabel;

    public FatorialView() {
        setLayout(new FlowLayout());

        inputField = new JTextField(10);
        add(getInputField());

        calculateButton = new JButton("Calcular Fatorial");
        getCalculateButton().addActionListener(new CalculateButtonListener());
        add(getCalculateButton());

        resultLabel = new JLabel("Resultado:");
        add(getResultLabel());

        setSize(250, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public String getInput() {
        return getInputField().getText();
    }

    public void setResult(String result) {
        getResultLabel().setText("Resultado: " + result);
    }

    private class CalculateButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            FatorialController controller = new FatorialController();
            try {
                String input = getInput();
                BigDecimal result = controller.calculateFatorial(input);
                setResult(result.toString());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(FatorialView.this, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FatorialView();
            }
        });
    }

	public JTextField getInputField() {
		return inputField;
	}

	public JLabel getResultLabel() {
		return resultLabel;
	}

	public JButton getCalculateButton() {
		return calculateButton;
	}
}