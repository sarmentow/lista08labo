package br.usp.ime.ex02;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import br.usp.ime.ex01.FatorialView;
public class FatorialViewTest {

    @Test
    public void testGetInput() {
        FatorialView view = new FatorialView();
        view.getInputField().setText("5");
        assertEquals("5", view.getInput());
    }

    @Test
    public void testSetResult() {
        FatorialView view = new FatorialView();
        view.setResult("120");
        assertEquals("Resultado: 120", view.getResultLabel().getText());
    }

    @Test
    public void testCalculateButtonListener() {
        FatorialView view = new FatorialView();
        view.getInputField().setText("5");
        view.getCalculateButton().doClick();
        assertEquals("Resultado: 120", view.getResultLabel().getText());
    }

    @Test
    public void testCalculateButtonListener_InvalidInput() {
        FatorialView view = new FatorialView();
        view.getInputField().setText("abc");
        assertThrows(RuntimeException.class, () -> view.getCalculateButton().doClick());
//        assertEquals("Error message", exception.getMessage());
    }

}
